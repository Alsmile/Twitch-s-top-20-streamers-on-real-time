# -*- coding: utf-8 -*-
"""
Created on Mon Apr 13 15:46:49 2020

@author: aaron
"""

import os

os.system('grabdata.py')
os.system('data_visualize.py')
os.system('data_chart.svg')